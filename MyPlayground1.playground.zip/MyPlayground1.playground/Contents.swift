import UIKit

var greeting :String = "Hello, playground"

var naujas =  "nieko nesakyk"
print(greeting)
print(naujas)

